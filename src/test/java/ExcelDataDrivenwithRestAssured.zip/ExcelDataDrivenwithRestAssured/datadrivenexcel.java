package ExcelDataDrivenwithRestAssured;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class datadrivenexcel {


@Test
public void addBook() throws IOException
{
	
 datadriven	d = new datadriven();
 ArrayList data = d.getdata("RestAddBook");
	
 HashMap<String, Object> map = new HashMap<String, Object>(); 	
 map.put("name",  data.get(1));
 map.put("isbn",  data.get(2)); 
 map.put("aisle", data.get(3));
 map.put("author",data.get(4));
	
	
 /*HashMap<String, Object> map2 = new HashMap<String, Object>();
 map.put("lat","12");
 map.put("lng", "45");
 map.put("location", map2);*/
 
	
 RestAssured.baseURI="https://rahulshettyacademy.com";	
 
 String resp = given().log().all().header("Content-Type", "application/json")
 .body(map)
 .when().post("/Library/Addbook.php")
 .then().assertThat().statusCode(200)
 .extract().response().asString();
 
 JsonPath js = new JsonPath(resp);
 String id = js.get("ID");
 
 System.out.println(id);
}
	
	
}
